import { encode, decode } from 'gpt-tokenizer';
import { updateApiUsage } from './firebase/admin';
import { auth } from './firebase';

const API_URL = 'https://api.openai.com/v1/chat/completions';
const API_KEY = import.meta.env.VITE_OPENAI_API_KEY;
const MAX_TOKENS = 4000;

const validateApiKey = () => {
  if (!API_KEY) {
    throw new Error('Clé API OpenAI non configurée');
  }
  return API_KEY;
};

const truncateContent = (content: string): string => {
  const tokens = encode(content);
  if (tokens.length > MAX_TOKENS) {
    const truncatedTokens = tokens.slice(0, MAX_TOKENS);
    return decode(truncatedTokens);
  }
  return content;
};

const callOpenAI = async (prompt: string, maxTokens: number = 800) => {
  const user = auth.currentUser;
  if (!user) throw new Error('Utilisateur non connecté');

  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${validateApiKey()}`
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      max_tokens: maxTokens
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error?.message || 'Erreur API OpenAI');
  }

  const data = await response.json();
  const result = data.choices?.[0]?.message?.content || '';
  
  // Calculer le nombre de tokens utilisés
  const promptTokens = encode(prompt).length;
  const responseTokens = encode(result).length;
  const totalTokens = promptTokens + responseTokens;

  // Mettre à jour les statistiques d'utilisation
  try {
    await updateApiUsage(user.uid, user.email || '', totalTokens);
  } catch (error) {
    console.error('Error updating API usage stats:', error);
  }

  return result;
};

export const generateExerciseSuggestions = async (
  classe: string,
  objectifs: string,
  duree: string,
  format?: string,
  sujetsPrefs?: string
): Promise<string[]> => {
  try {
    const prompt = `En tant que professeur de français pour une classe de ${classe}, proposez 3 sujets d'évaluation différents.

Objectifs pédagogiques: ${objectifs}
Durée prévue: ${duree}
${format ? `Format souhaité: ${format}` : ''}
${sujetsPrefs ? `Centres d'intérêt des élèves: ${sujetsPrefs}` : ''}

Format de réponse souhaité:
- Proposez exactement 3 sujets
- Chaque sujet doit être concis et clair
- Adaptez le niveau de difficulté à la classe
- Assurez-vous que les sujets permettent d'évaluer les objectifs pédagogiques`;

    const response = await callOpenAI(prompt, 1000);
    return response.split('\n').filter(line => line.trim().length > 0 && !line.startsWith('-'));
  } catch (error: any) {
    console.error('OpenAI API Error:', error);
    throw new Error(error.message || 'Erreur lors de la génération des suggestions');
  }
};

export const generateBaremeSuggestion = async (
  classe: string,
  sujet: string,
  totalPoints: number
): Promise<Array<{ id: string; description: string; points: number }>> => {
  try {
    const prompt = `En tant que professeur de français pour une classe de ${classe}, proposez un barème détaillé pour le sujet suivant:

Sujet: ${sujet}
Points totaux: ${totalPoints}

Format de réponse souhaité:
- Listez les critères d'évaluation
- Pour chaque critère, indiquez les points attribués
- Le total des points doit être exactement ${totalPoints}
- Adaptez les critères au niveau de la classe
- Format: Critère: X points`;

    const response = await callOpenAI(prompt, 800);
    const lines = response.split('\n').filter(line => line.includes(':'));
    
    return lines.map(line => {
      const [description, pointsStr] = line.split(':').map(s => s.trim());
      const points = parseInt(pointsStr);
      return {
        id: crypto.randomUUID(),
        description,
        points: isNaN(points) ? 0 : points
      };
    });
  } catch (error: any) {
    console.error('OpenAI API Error:', error);
    throw new Error(error.message || 'Erreur lors de la génération du barème');
  }
};

export const generateCourseContent = async (
  classe: string,
  titre: string,
  description: string,
  duree: string,
  objectifs: string[],
  interetsEleves: string,
  ressources: string[]
): Promise<string> => {
  try {
    const prompt = `Tu es professeur de français depuis de nombreuses années. Tu dois créer un cours intéressant et impactant pour tes élèves de ${classe} sur le sujet de "${titre}" en suivant les éléments précisés dans la description: "${description}".

Règles:
- Le cours doit être adapté pour une durée de ${duree}
- Il doit permettre d'atteindre les objectifs pédagogiques suivants:
${objectifs.map(obj => `  - ${obj}`).join('\n')}
${interetsEleves ? `- Il doit être basé sur les centres d'intérêt des élèves suivants: ${interetsEleves}` : ''}
${ressources.length > 0 ? `- Il doit utiliser les ressources pédagogiques suivantes:\n${ressources.map(res => `  - ${res}`).join('\n')}` : ''}
- Il doit être le plus interactif possible, avec:
  - Des parties théoriques claires et structurées
  - Des exemples concrets et pertinents
  - Des exercices pratiques
  - Des activités interactives entre élèves
  - Des moments de réflexion et de discussion

Format de réponse:
- Utilise le format Markdown pour structurer le contenu
- Inclus des titres, sous-titres, listes, etc.
- Sépare clairement les différentes parties du cours
- Détaille chaque activité et exercice
- Indique les durées approximatives pour chaque partie`;

    return await callOpenAI(prompt, 2000);
  } catch (error: any) {
    console.error('OpenAI API Error:', error);
    throw new Error(error.message || 'Erreur lors de la génération du contenu du cours');
  }
};