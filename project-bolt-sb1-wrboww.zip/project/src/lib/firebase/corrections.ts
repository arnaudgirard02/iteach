import { collection, doc, getDoc, getDocs, addDoc, updateDoc, deleteDoc, query, where, orderBy, Timestamp } from 'firebase/firestore';
import { db } from '../firebase';
import type { CorrectionProject, CorrectionCopy } from '../../types/correction';

export const CORRECTIONS_COLLECTION = 'corrections';

const prepareForFirestore = (data: any): any => {
  if (data instanceof Date) {
    return Timestamp.fromDate(data);
  }
  if (Array.isArray(data)) {
    return data.map(prepareForFirestore);
  }
  if (data && typeof data === 'object') {
    return Object.keys(data).reduce((result, key) => ({
      ...result,
      [key]: prepareForFirestore(data[key])
    }), {});
  }
  return data;
};

export const saveCorrection = async (data: Omit<CorrectionProject, 'id'>) => {
  if (!data.userId) {
    throw new Error('User ID is required');
  }

  try {
    const docRef = await addDoc(collection(db, CORRECTIONS_COLLECTION), prepareForFirestore(data));
    return docRef.id;
  } catch (error) {
    console.error('Error saving correction:', error);
    throw error;
  }
};

export const getCorrection = async (id: string): Promise<CorrectionProject | null> => {
  if (!id) {
    throw new Error('Correction ID is required');
  }

  try {
    const docRef = doc(db, CORRECTIONS_COLLECTION, id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        ...data,
        createdAt: data.createdAt.toDate(),
        updatedAt: data.updatedAt.toDate(),
        copies: data.copies.map((copy: any) => ({
          ...copy,
          createdAt: copy.createdAt instanceof Timestamp ? copy.createdAt.toDate() : new Date(copy.createdAt)
        }))
      } as CorrectionProject;
    }
    return null;
  } catch (error) {
    console.error('Error getting correction:', error);
    throw error;
  }
};

export const getUserCorrections = async (userId: string): Promise<CorrectionProject[]> => {
  if (!userId) {
    throw new Error('User ID is required');
  }

  try {
    const q = query(
      collection(db, CORRECTIONS_COLLECTION),
      where('userId', '==', userId),
      orderBy('updatedAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        createdAt: data.createdAt instanceof Timestamp ? data.createdAt.toDate() : new Date(data.createdAt),
        updatedAt: data.updatedAt instanceof Timestamp ? data.updatedAt.toDate() : new Date(data.updatedAt),
        copies: (data.copies || []).map((copy: any) => ({
          ...copy,
          createdAt: copy.createdAt instanceof Timestamp ? copy.createdAt.toDate() : new Date(copy.createdAt)
        }))
      } as CorrectionProject;
    });
  } catch (error) {
    console.error('Error getting user corrections:', error);
    throw error;
  }
};

export const updateCorrection = async (id: string, data: Partial<CorrectionProject>) => {
  if (!id) {
    throw new Error('Correction ID is required');
  }

  try {
    const docRef = doc(db, CORRECTIONS_COLLECTION, id);
    
    // Prepare the update data
    const updateData = prepareForFirestore({
      ...data,
      updatedAt: new Date()
    });

    await updateDoc(docRef, updateData);
  } catch (error) {
    console.error('Error updating correction:', error);
    throw error;
  }
};

export const deleteCorrection = async (id: string) => {
  if (!id) {
    throw new Error('Correction ID is required');
  }

  try {
    const docRef = doc(db, CORRECTIONS_COLLECTION, id);
    await deleteDoc(docRef);
  } catch (error) {
    console.error('Error deleting correction:', error);
    throw error;
  }
};