import { collection, doc, getDoc, getDocs, setDoc, updateDoc, query, where, orderBy, Timestamp, runTransaction } from 'firebase/firestore';
import { db } from '../firebase';
import type { ApiUsage, GlobalApiStats } from '../../types/admin';

export const API_USAGE_COLLECTION = 'api_usage';
export const GLOBAL_STATS_COLLECTION = 'global_stats';
const ADMIN_EMAIL = 'arnaud7.girard@hotmail.fr';

export const isAdmin = (email: string | null) => {
  return email === ADMIN_EMAIL;
};

export const updateApiUsage = async (userId: string, userEmail: string, tokensUsed: number) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const userRef = doc(db, API_USAGE_COLLECTION, userId);
    const globalRef = doc(db, GLOBAL_STATS_COLLECTION, 'current');

    await runTransaction(db, async (transaction) => {
      // Update user statistics
      const userDoc = await transaction.get(userRef);
      if (userDoc.exists()) {
        const userData = userDoc.data();
        const userUsageByDay = [...(userData.usageByDay || [])];
        const userTodayIndex = userUsageByDay.findIndex(d => d.date === today);

        if (userTodayIndex >= 0) {
          userUsageByDay[userTodayIndex] = {
            date: today,
            apiCalls: userUsageByDay[userTodayIndex].apiCalls + 1,
            tokens: userUsageByDay[userTodayIndex].tokens + tokensUsed
          };
        } else {
          userUsageByDay.push({ date: today, apiCalls: 1, tokens: tokensUsed });
        }

        transaction.update(userRef, {
          totalApiCalls: (userData.totalApiCalls || 0) + 1,
          totalTokens: (userData.totalTokens || 0) + tokensUsed,
          lastUpdated: Timestamp.now(),
          usageByDay: userUsageByDay
        });
      } else {
        transaction.set(userRef, {
          userId,
          userEmail,
          totalApiCalls: 1,
          totalTokens: tokensUsed,
          lastUpdated: Timestamp.now(),
          usageByDay: [{ date: today, apiCalls: 1, tokens: tokensUsed }]
        });
      }

      // Update global statistics
      const globalDoc = await transaction.get(globalRef);
      if (globalDoc.exists()) {
        const globalData = globalDoc.data();
        const globalUsageByDay = [...(globalData.usageByDay || [])];
        const globalTodayIndex = globalUsageByDay.findIndex(d => d.date === today);

        if (globalTodayIndex >= 0) {
          globalUsageByDay[globalTodayIndex] = {
            date: today,
            apiCalls: globalUsageByDay[globalTodayIndex].apiCalls + 1,
            tokens: globalUsageByDay[globalTodayIndex].tokens + tokensUsed
          };
        } else {
          globalUsageByDay.push({ date: today, apiCalls: 1, tokens: tokensUsed });
        }

        transaction.update(globalRef, {
          totalApiCalls: (globalData.totalApiCalls || 0) + 1,
          totalTokens: (globalData.totalTokens || 0) + tokensUsed,
          lastUpdated: Timestamp.now(),
          usageByDay: globalUsageByDay
        });
      } else {
        transaction.set(globalRef, {
          totalApiCalls: 1,
          totalTokens: tokensUsed,
          lastUpdated: Timestamp.now(),
          usageByDay: [{ date: today, apiCalls: 1, tokens: tokensUsed }]
        });
      }
    });
  } catch (error) {
    console.error('Error updating API usage:', error);
    throw error;
  }
};

export const getGlobalStats = async (): Promise<GlobalApiStats> => {
  try {
    const docRef = doc(db, GLOBAL_STATS_COLLECTION, 'current');
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      const data = docSnap.data();
      return {
        ...data,
        lastUpdated: data.lastUpdated.toDate()
      } as GlobalApiStats;
    }
    
    return {
      totalApiCalls: 0,
      totalTokens: 0,
      lastUpdated: new Date(),
      usageByDay: []
    };
  } catch (error) {
    console.error('Error getting global stats:', error);
    throw error;
  }
};

export const getAllUsersApiUsage = async (): Promise<ApiUsage[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, API_USAGE_COLLECTION));
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      lastUpdated: doc.data().lastUpdated.toDate()
    })) as ApiUsage[];
  } catch (error) {
    console.error('Error getting all users API usage:', error);
    throw error;
  }
};