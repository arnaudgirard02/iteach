import { collection, doc, getDoc, getDocs, setDoc, query, where, orderBy, Timestamp } from 'firebase/firestore';
import { db } from '../firebase';
import type { ClassAnalytics, StudentProgress } from '../../types/analytics';

export const ANALYTICS_COLLECTION = 'analytics';

// Créer ou mettre à jour les analytics
export const updateAnalytics = async (userId: string, classe: string, grade: number) => {
  try {
    const docRef = doc(db, ANALYTICS_COLLECTION, `${userId}_${classe}`);
    const docSnap = await getDoc(docRef);
    
    const now = new Date();
    const progress: StudentProgress = {
      correctionId: crypto.randomUUID(),
      grade,
      date: now
    };

    if (docSnap.exists()) {
      const data = docSnap.data();
      const studentProgress = [...(data.studentProgress || []), progress];
      
      // Calculer la moyenne
      const averageGrade = studentProgress.reduce((sum, p) => sum + p.grade, 0) / studentProgress.length;
      
      // Calculer le taux de réussite (notes >= 10)
      const successRate = (studentProgress.filter(p => p.grade >= 10).length / studentProgress.length) * 100;
      
      // Calculer la progression mensuelle
      const lastMonthProgress = studentProgress
        .filter(p => p.date instanceof Timestamp ? 
          p.date.toDate().getMonth() === now.getMonth() - 1 : 
          new Date(p.date).getMonth() === now.getMonth() - 1
        );
      const thisMonthProgress = studentProgress
        .filter(p => p.date instanceof Timestamp ? 
          p.date.toDate().getMonth() === now.getMonth() : 
          new Date(p.date).getMonth() === now.getMonth()
        );
      
      const lastMonthAvg = lastMonthProgress.length > 0 
        ? lastMonthProgress.reduce((sum, p) => sum + p.grade, 0) / lastMonthProgress.length 
        : 0;
      const thisMonthAvg = thisMonthProgress.length > 0 
        ? thisMonthProgress.reduce((sum, p) => sum + p.grade, 0) / thisMonthProgress.length 
        : 0;
      
      const monthlyProgress = lastMonthAvg > 0 
        ? ((thisMonthAvg - lastMonthAvg) / lastMonthAvg) * 100 
        : 0;

      await setDoc(docRef, {
        userId,
        classe,
        averageGrade,
        successRate,
        monthlyProgress,
        studentProgress,
        updatedAt: Timestamp.now()
      });
    } else {
      // Première note pour cette classe
      await setDoc(docRef, {
        userId,
        classe,
        averageGrade: grade,
        successRate: grade >= 10 ? 100 : 0,
        monthlyProgress: 0,
        studentProgress: [progress],
        updatedAt: Timestamp.now()
      });
    }
  } catch (error) {
    console.error('Error updating analytics:', error);
    throw error;
  }
};

export const getAllUserAnalytics = async (userId: string): Promise<ClassAnalytics[]> => {
  try {
    const q = query(
      collection(db, ANALYTICS_COLLECTION),
      where('userId', '==', userId),
      orderBy('updatedAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      updatedAt: doc.data().updatedAt.toDate(),
      studentProgress: doc.data().studentProgress.map((p: any) => ({
        ...p,
        date: p.date instanceof Timestamp ? p.date.toDate() : new Date(p.date)
      }))
    })) as ClassAnalytics[];
  } catch (error) {
    console.error('Error getting user analytics:', error);
    throw error;
  }
};