import React from 'react';
import ReactMarkdown from 'react-markdown';

interface Props {
  title: string;
  description: string;
  classe: string;
  duration: string;
  objectives: string[];
  content: string;
  resources: string[];
}

export default function CourseView({
  title,
  description,
  classe,
  duration,
  objectives,
  content,
  resources
}: Props) {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-6 py-5 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
        <p className="mt-1 text-sm text-gray-500">
          {classe} • {duration}
        </p>
      </div>
      <div className="px-6 py-5 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Description</h2>
        <p className="mt-2 text-gray-600">{description}</p>
      </div>
      <div className="px-6 py-5 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Objectifs</h2>
        <ul className="mt-2 list-disc list-inside space-y-1">
          {objectives.map((objective, index) => (
            <li key={index} className="text-gray-600">{objective}</li>
          ))}
        </ul>
      </div>
      <div className="px-6 py-5">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Contenu du cours</h2>
        <div className="prose max-w-none">
          <ReactMarkdown>{content}</ReactMarkdown>
        </div>
      </div>
      {resources.length > 0 && (
        <div className="px-6 py-5 border-t border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Ressources supplémentaires</h2>
          <ul className="mt-2 list-disc list-inside space-y-1">
            {resources.map((resource, index) => (
              <li key={index} className="text-gray-600">
                <a href={resource} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-500">
                  {resource}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}