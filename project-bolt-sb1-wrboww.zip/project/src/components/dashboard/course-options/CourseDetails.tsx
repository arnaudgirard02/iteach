import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Loader } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useAuth } from '../../../contexts/AuthContext';
import { getDoc, doc } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { updateCourse } from '../../../lib/firebase/courses';
import type { Course } from '../../../types/course';
import CourseHeader from './CourseHeader';
import CourseForm from './CourseForm';
import CourseView from './CourseView';

const DURATIONS = [
  '30 minutes',
  '45 minutes',
  '1 heure',
  '1 heure 30',
  '2 heures',
  '3 heures',
  '4 heures',
  '6 heures',
  '8 heures',
  '10 heures',
  '12 heures',
  '15 heures',
  '20 heures'
];

export default function CourseDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [classe, setClasse] = useState('');
  const [duration, setDuration] = useState(DURATIONS[2]);
  const [objectives, setObjectives] = useState<string[]>(['']);
  const [content, setContent] = useState('');
  const [resources, setResources] = useState<string[]>(['']);

  useEffect(() => {
    const loadCourse = async () => {
      if (!id || !user) return;

      try {
        const docRef = doc(db, 'courses', id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists() && docSnap.data().userId === user.uid) {
          const courseData = {
            id: docSnap.id,
            ...docSnap.data()
          } as Course;

          setTitle(courseData.title);
          setDescription(courseData.description);
          setClasse(courseData.classe);
          setDuration(courseData.duration);
          setObjectives(courseData.objectives);
          setContent(courseData.content);
          setResources(courseData.resources);
        } else {
          toast.error('Cours non trouvé');
          navigate('/dashboard/courses');
        }
      } catch (error) {
        console.error('Error loading course:', error);
        toast.error('Erreur lors du chargement du cours');
      } finally {
        setIsLoading(false);
      }
    };

    loadCourse();
  }, [id, user]);

  const handleSave = async () => {
    if (!id || !user) return;

    if (!title || !description || !classe || !content || objectives.some(obj => !obj)) {
      toast.error('Veuillez remplir tous les champs obligatoires');
      return;
    }

    setIsSaving(true);

    try {
      const updatedData = {
        title,
        description,
        classe,
        duration,
        objectives: objectives.filter(Boolean),
        content,
        resources: resources.filter(Boolean),
        updatedAt: new Date()
      };

      await updateCourse(id, updatedData);
      toast.success('Cours mis à jour avec succès');
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating course:', error);
      toast.error('Erreur lors de la mise à jour du cours');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader className="h-8 w-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <CourseHeader
          isEditing={isEditing}
          isSaving={isSaving}
          onBack={() => navigate('/dashboard/courses')}
          onEdit={() => setIsEditing(true)}
          onCancel={() => setIsEditing(false)}
          onSave={handleSave}
        />

        {isEditing ? (
          <div className="bg-white shadow rounded-lg p-6">
            <CourseForm
              title={title}
              description={description}
              classe={classe}
              duration={duration}
              objectives={objectives}
              content={content}
              resources={resources}
              durations={DURATIONS}
              onTitleChange={setTitle}
              onDescriptionChange={setDescription}
              onClasseChange={setClasse}
              onDurationChange={setDuration}
              onObjectiveAdd={() => setObjectives([...objectives, ''])}
              onObjectiveRemove={(index) => setObjectives(objectives.filter((_, i) => i !== index))}
              onObjectiveChange={(index, value) => setObjectives(objectives.map((obj, i) => i === index ? value : obj))}
              onContentChange={setContent}
              onResourceAdd={() => setResources([...resources, ''])}
              onResourceRemove={(index) => setResources(resources.filter((_, i) => i !== index))}
              onResourceChange={(index, value) => setResources(resources.map((res, i) => i === index ? value : res))}
            />
          </div>
        ) : (
          <CourseView
            title={title}
            description={description}
            classe={classe}
            duration={duration}
            objectives={objectives}
            content={content}
            resources={resources}
          />
        )}
      </div>
    </div>
  );
}