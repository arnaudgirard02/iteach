import React from 'react';
import { ArrowLeft, Save, Loader } from 'lucide-react';

interface Props {
  isEditing: boolean;
  isSaving: boolean;
  onBack: () => void;
  onEdit: () => void;
  onCancel: () => void;
  onSave: () => void;
}

export default function CourseHeader({ 
  isEditing, 
  isSaving, 
  onBack, 
  onEdit, 
  onCancel, 
  onSave 
}: Props) {
  return (
    <div className="flex justify-between items-center mb-8">
      <button
        onClick={onBack}
        className="inline-flex items-center text-gray-600 hover:text-gray-900"
      >
        <ArrowLeft className="h-5 w-5 mr-2" />
        Retour aux cours
      </button>
      <div className="flex gap-4">
        {!isEditing ? (
          <button
            onClick={onEdit}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Modifier
          </button>
        ) : (
          <>
            <button
              onClick={onCancel}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Annuler
            </button>
            <button
              onClick={onSave}
              disabled={isSaving}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <Loader className="animate-spin h-4 w-4 mr-2" />
                  Enregistrement...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Enregistrer
                </>
              )}
            </button>
          </>
        )}
      </div>
    </div>
  );
}