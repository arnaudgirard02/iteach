import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import ClassSelector from '../correction-options/ClassSelector';

interface Props {
  title: string;
  description: string;
  classe: string;
  duration: string;
  objectives: string[];
  content: string;
  resources: string[];
  durations: string[];
  onTitleChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onClasseChange: (value: string) => void;
  onDurationChange: (value: string) => void;
  onObjectiveAdd: () => void;
  onObjectiveRemove: (index: number) => void;
  onObjectiveChange: (index: number, value: string) => void;
  onContentChange: (value: string) => void;
  onResourceAdd: () => void;
  onResourceRemove: (index: number) => void;
  onResourceChange: (index: number, value: string) => void;
}

export default function CourseForm({
  title,
  description,
  classe,
  duration,
  objectives,
  content,
  resources,
  durations,
  onTitleChange,
  onDescriptionChange,
  onClasseChange,
  onDurationChange,
  onObjectiveAdd,
  onObjectiveRemove,
  onObjectiveChange,
  onContentChange,
  onResourceAdd,
  onResourceRemove,
  onResourceChange,
}: Props) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Titre du cours
        </label>
        <input
          type="text"
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Description
        </label>
        <textarea
          value={description}
          onChange={(e) => onDescriptionChange(e.target.value)}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Classe
          </label>
          <ClassSelector
            value={classe}
            onChange={onClasseChange}
            className="mt-1"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Durée
          </label>
          <select
            value={duration}
            onChange={(e) => onDurationChange(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            {durations.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center mb-2">
          <label className="block text-sm font-medium text-gray-700">
            Objectifs pédagogiques
          </label>
          <button
            type="button"
            onClick={onObjectiveAdd}
            className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
          >
            <Plus className="h-4 w-4 mr-1" />
            Ajouter un objectif
          </button>
        </div>
        <div className="space-y-2">
          {objectives.map((objective, index) => (
            <div key={index} className="flex gap-2">
              <input
                type="text"
                value={objective}
                onChange={(e) => onObjectiveChange(index, e.target.value)}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
              {objectives.length > 1 && (
                <button
                  type="button"
                  onClick={() => onObjectiveRemove(index)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">
          Contenu du cours
        </label>
        <textarea
          value={content}
          onChange={(e) => onContentChange(e.target.value)}
          rows={20}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 font-mono"
        />
      </div>

      <div>
        <div className="flex justify-between items-center mb-2">
          <label className="block text-sm font-medium text-gray-700">
            Ressources pédagogiques (optionnel)
          </label>
          <button
            type="button"
            onClick={onResourceAdd}
            className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
          >
            <Plus className="h-4 w-4 mr-1" />
            Ajouter une ressource
          </button>
        </div>
        <div className="space-y-2">
          {resources.map((resource, index) => (
            <div key={index} className="flex gap-2">
              <input
                type="text"
                value={resource}
                onChange={(e) => onResourceChange(index, e.target.value)}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={() => onResourceRemove(index)}
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}