export interface ApiUsage {
  id?: string;
  userId: string;
  userEmail: string;
  totalApiCalls: number;
  totalTokens: number;
  lastUpdated: Date;
  usageByDay: {
    date: string;
    apiCalls: number;
    tokens: number;
  }[];
}

export interface GlobalApiStats {
  id?: string;
  totalApiCalls: number;
  totalTokens: number;
  lastUpdated: Date;
  usageByDay: {
    date: string;
    apiCalls: number;
    tokens: number;
  }[];
}